import os
import warnings
import streamlit as st
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories import ChatMessageHistory

# Hide Pydantic warnings
warnings.filterwarnings("ignore", category=UserWarning, module="langchain_core")

# 1. Page Configuration
st.set_page_config(
    page_title="Nexus AI Chatbot",
    page_icon="✨",
    layout="centered",
    initial_sidebar_state="expanded"
)

# Load environment variables
load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# 2. Premium Light Mode Designing & Custom CSS
st.markdown("""
    <style>
    /* Main Background & Font */
    .stApp {
        background: linear-gradient(135deg, #f6f8fb 0%, #f1f5f9 100%);
        color: #1e293b;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}

    /* Sidebar Premium Styling */
    [data-testid="stSidebar"] {
        background-color: #ffffff;
        border-right: 1px solid #e2e8f0;
        box-shadow: 4px 0 24px rgba(0, 0, 0, 0.02);
        padding-top: 1rem;
    }

    /* Header Title Designing */
    .main-title {
        font-size: 2rem;
        font-weight: 800;
        background: linear-gradient(90deg, #4f46e5, #7c3aed, #db2777);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 0px;
        letter-spacing: -0.5px;
    }
    .sub-title {
        text-align: center;
        color: #64748b;
        font-size: 0.9rem;
        margin-bottom: 2rem;
        font-weight: 400;
    }
    
    /* Modern Buttons */
    .stButton button {
        background: linear-gradient(90deg, #4f46e5, #7c3aed);
        color: white;
        border: none;
        border-radius: 10px;
        font-weight: 600;
        padding: 0.6rem 1rem;
        transition: all 0.3s ease;
        width: 100%;
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.2);
    }
    .stButton button:hover {
        background: linear-gradient(90deg, #4338ca, #6d28d9);
        box-shadow: 0 6px 16px rgba(79, 70, 229, 0.35);
        transform: translateY(-1px);
    }

    /* Chat Messages Styling (ChatGPT style distinct card look) */
    [data-testid="stChatMessage"] {
        background-color: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 1.2rem;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
        margin-bottom: 1rem;
    }
    
    /* Input Field Enhancement */
    .stChatInput {
        border-radius: 14px !important;
    }
    </style>
""", unsafe_allow_html=True)

# 3. Sidebar Configuration
with st.sidebar:
    st.markdown("### ⚙️ Control Panel")
    st.markdown("---")
    
    api_key_input = st.text_input("Groq API Key", type="password", value=GROQ_API_KEY or "", help="Enter your Groq API key")
    
    model_name = st.selectbox(
        "🧠 Select Model",
        ["llama-3.3-70b-versatile", "llama-3.1-8b-instant"],
        index=0
    )
    
    temperature = st.slider("🌡️ Creativity (Temperature)", 0.0, 1.0, 0.7, 0.1)
    
    st.markdown("---")
    
    if st.button("🗑️ Clear History"):
        st.session_state.clear()
        st.rerun()
        
    st.markdown("<div style='text-align: center; color: #94a3b8; font-size: 0.75rem; margin-top: 50px;'>Powered by Groq & LangChain</div>", unsafe_allow_html=True)

# Header Section
st.markdown('<p class="main-title">✨ Nexus AI Chatbot</p>', unsafe_allow_html=True)
st.markdown('<p class="sub-title">Context & History Aware Assistant</p>', unsafe_allow_html=True)

# API Key Check
if not api_key_input:
    st.warning("⚠️ Please enter your Groq API Key in the sidebar to start chatting. *(Tip: Agar sidebar band hai, toh page refresh/F5 kar lein).*")
    st.stop()

# 4. LangChain LLM & Memory Setup
llm = ChatGroq(
    groq_api_key=api_key_input,
    model_name=model_name,
    temperature=temperature
)

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a professional, helpful, and intelligent AI assistant. Use the conversation history and context to provide accurate answers."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

chain = prompt | llm

# Session Store for History
if "chat_history_store" not in st.session_state:
    st.session_state.chat_history_store = {}

def get_session_history(session_id: str):
    if session_id not in st.session_state.chat_history_store:
        st.session_state.chat_history_store[session_id] = ChatMessageHistory()
    return st.session_state.chat_history_store[session_id]

conversational_chain = RunnableWithMessageHistory(
    chain,
    get_session_history,
    input_messages_key="input",
    history_messages_key="history",
)

# 5. Display Messages
if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"], avatar="👤" if message["role"] == "user" else "🤖"):
        st.markdown(message["content"])

# 6. User Input Handler
session_id = "default_user_session"

if user_input := st.chat_input("Type your message here..."):
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user", avatar="👤"):
        st.markdown(user_input)

    with st.chat_message("assistant", avatar="🤖"):
        with st.spinner("Thinking..."):
            try:
                config = {"configurable": {"session_id": session_id}}
                response = conversational_chain.invoke(
                    {"input": user_input},
                    config=config
                )
                ai_response = response.content
                st.markdown(ai_response)
                
                st.session_state.messages.append({"role": "assistant", "content": ai_response})
            except Exception as e:
                st.error(f"Error: {e}")